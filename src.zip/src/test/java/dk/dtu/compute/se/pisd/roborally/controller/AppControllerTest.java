package dk.dtu.compute.se.pisd.roborally.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AppControllerTest {

    @Test
    void newGame() {
    }
}